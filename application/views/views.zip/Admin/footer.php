<script type="text/javascript">
$(document).ready(function(){
  $("body").addClass("sidebar-collapse");
});
</script>
<footer class="main-footer">
  <strong>Copyright &copy; 2019 Newspaper  </strong>
  All rights reserved.
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b>1.0
  </div>
</footer>
